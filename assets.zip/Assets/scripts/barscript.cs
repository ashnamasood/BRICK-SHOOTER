using UnityEngine;

public class barscript : MonoBehaviour
{
    public float moveSpeed = 10f; // Speed at which the bar moves left and right

    private void Update()
    {
        float horizontalInput = Input.GetAxis("Horizontal");

        transform.Translate(Vector2.right * horizontalInput * moveSpeed * Time.deltaTime);

        float xPos = Mathf.Clamp(transform.position.x, -8f, 8f);
        transform.position = new Vector3(xPos, transform.position.y, transform.position.z);
    }
    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("Ball"))
        {
            Rigidbody2D ballRb = collision.gameObject.GetComponent<Rigidbody2D>();

            // Calculate the horizontal offset from the center of the bar
            float hitOffset = collision.transform.position.x - transform.position.x;

            // Set up the horizontal bounce effect
            float horizontalBounceFactor = 1.5f; // Adjust this for more or less horizontal bounce
            float bounceDirectionX = hitOffset * horizontalBounceFactor;

            // Reverse the y-velocity to ensure the ball bounces upwards
            Vector2 newVelocity = new Vector2(bounceDirectionX, Mathf.Abs(ballRb.velocity.y));

            // Apply the new velocity to the ball
            ballRb.velocity = newVelocity;
        }
    }



}