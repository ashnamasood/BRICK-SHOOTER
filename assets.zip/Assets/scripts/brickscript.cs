using UnityEngine;
using System.Collections;

public class brickscript : MonoBehaviour
{
    public int HitsRequired = 1; // Number of hits this brick needs to be destroyed
    public GameObject NextBrick; // The next weaker brick in the sequence
    public int ScoreValue = 5;
    int bricks = 4;

    private AudioSource audioSource; // Reference to the AudioSource component
    private Collider2D brickCollider; // Reference to the brick's collider
    private bool isHit = false; // Flag to track if the brick has been recently hit

    private gamescript gameScript; // Reference to gamescript

    void Start()
    {
        // Get the AudioSource and Collider components
        audioSource = GetComponent<AudioSource>();
        brickCollider = GetComponent<Collider2D>();

        // Find the gamescript on the GameManager GameObject
        gameScript = GameObject.Find("GameManager").GetComponent<gamescript>();
    }

    void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("Ball") && !isHit)
        {
            // Start coroutine to handle single-hit transition
            StartCoroutine(HandleSingleHit(collision));
        }
    }

    private IEnumerator HandleSingleHit(Collision2D collision)
    {
        isHit = true; // Mark as hit to prevent multiple triggers

        // Play the collision sound
        if (audioSource != null)
        {
            audioSource.Play();
        }

        // Reflect the ball's direction on hit
        Rigidbody2D ballRb = collision.gameObject.GetComponent<Rigidbody2D>();
        ballRb.velocity = new Vector2(ballRb.velocity.x, -ballRb.velocity.y);

        HitsRequired--; // Decrement hits required to destroy
        Debug.Log("Brick hit! Hits remaining: " + HitsRequired);

        if (HitsRequired <= 0)
        {
            bricks--;
            // Add score before destruction
            if (gameScript != null)
            {
                gameScript.AddScore(ScoreValue); // Update score
            }

            // Instantiate the next brick if there is one
            if (NextBrick != null)
            {
                Instantiate(NextBrick, transform.position, Quaternion.identity);
                Debug.Log("Instantiated next brick: " + NextBrick.name);
            }
            else
            {
                Debug.Log("No next brick. Destroying brick completely.");
            }

            // Call CheckWinCondition before destruction to verify if all bricks are destroyed
            if (gameScript != null)
            {
                gameScript.CheckWinCondition();
            }

            // Slight delay for brick destruction
            Destroy(gameObject, 0.05f); // Delay to allow for the effects (like the score update)
        }

        // Temporarily disable the collider to prevent additional hits
        brickCollider.enabled = false;

        // Wait for a short duration before re-enabling collider
        yield return new WaitForSeconds(0.3f);

        // Re-enable collider and reset the hit flag
        brickCollider.enabled = true;
        isHit = false;
    }

}