using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class gamescript : MonoBehaviour
{
    public Text ScoreText; // Reference to the UI Text component for score display
    public GameObject GameOverCanvas; // Reference to Game Over Canvas
    public GameObject WinCanvas; // Reference to Win Canvas

    private int score = 0; // Initial score

    void Start()
    {
        // Initially deactivate Game Over and Win canvases
        GameOverCanvas.SetActive(false);
        WinCanvas.SetActive(false);

        // Initialize the score display
        UpdateScoreText();
    }

    // Method to add score
    public void AddScore(int points)
    {
        score += points;
        UpdateScoreText();
    }

    // Update the ScoreText UI
    private void UpdateScoreText()
    {
        ScoreText.text = "Score: " + score;
    }

    // Method to handle Game Over
    public void GameOver()
    {
        GameOverCanvas.SetActive(true);
    }

    // Method to restart the game
    public void RestartGame()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }

    // gamescript class
    public void CheckWinCondition()
    {
        // Find all bricks with the tag "brick"
        var bricks = GameObject.FindGameObjectsWithTag("brick");
        Debug.Log("Bricks remaining: " + bricks.Length);

        // If no bricks remain, show WinCanvas
        if (bricks.Length == 1)
        {
            WinCanvas.SetActive(true); // Show the win screen
        }
    }


}
