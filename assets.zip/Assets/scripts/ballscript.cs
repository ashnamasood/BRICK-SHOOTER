using UnityEngine;

public class ballscript : MonoBehaviour
{
    public float speed = 500f;  // Set this to control the speed of the ball
    private Rigidbody2D rb;
    private Vector2 lastVelocity;

    // Reference to the gamescript to trigger game over
    private gamescript gameScript;

    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        gameScript = FindObjectOfType<gamescript>(); // Find the gamescript instance
        LaunchBall();
    }

    void LaunchBall()
    {
        // Initial launch force for the ball
        rb.AddForce(new Vector2(50f, 180f));
    }

    void Update()
    {
        lastVelocity = rb.velocity;

        // Keep the speed consistent by normalizing the velocity vector and scaling by the desired speed
        rb.velocity = lastVelocity.normalized * speed * Time.deltaTime;

        // Check if the ball falls below a certain point (Y position), game over
        if (transform.position.y < -5f)
        {
            gameScript.GameOver();  // Trigger the Game Over screen
        }
    }

    void OnCollisionEnter2D(Collision2D collision)
    {
        // Reverse velocity based on collision with walls or paddle
        if (collision.gameObject.name.Equals("cieling"))
        {
            lastVelocity.y *= -1f;  // Reverse Y velocity for top wall
            rb.velocity = lastVelocity.normalized * speed * Time.deltaTime;
        }
        else if (collision.gameObject.name.Equals("paddle"))
        {
            lastVelocity.x *= -1f;  // Reverse X velocity for paddle
            rb.velocity = lastVelocity.normalized * speed * Time.deltaTime;
        }
        else if (collision.gameObject.CompareTag("bar") || collision.gameObject.CompareTag("brick"))
        {
            // Reflect velocity based on the collision normal for paddle and bricks
            Vector2 reflectDir = Vector2.Reflect(lastVelocity.normalized, collision.contacts[0].normal);
            rb.velocity = reflectDir * speed * Time.deltaTime;
        }
        // If ball collides with the lower wall (assuming "LowerWall" tag for the wall)
        else if (collision.gameObject.CompareTag("lowerwall"))
        {
            gameScript.GameOver();  // Trigger Game Over when the ball hits the lower wall
        }
    }
}
